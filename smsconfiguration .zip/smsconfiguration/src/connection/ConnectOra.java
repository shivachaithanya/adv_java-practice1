package connection;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectOra
{
	private static final long serialVersionUID=1L;
	Connection con = null;
	 public Connection conn() throws Exception 
	{
         String dbURL = "jdbc:oracle:thin:@oradevdb.hpcl.co.in:1551:oradevdb";
		 String dbDriver = "oracle.jdbc.driver.OracleDriver";		 					 
		 Class.forName(dbDriver);		
         con = DriverManager.getConnection(dbURL,"sms","sms");                         
		 return con; 
	} 
}
