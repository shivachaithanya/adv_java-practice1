package QrcodeGenerator;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.glxn.qrgen.QRCode;
import net.glxn.qrgen.image.ImageType;


public class QrGenerator extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	@Override
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		String xmldata = request.getParameter("qrtext");
		xmldata = "<PrintLetterBarcodeData uid=\"8106860298\" name=\" shivachaitanya\" gender=\"M\" yob=\"1994\" co=\"S/O: prathap reddy\" house=\"plot no-44 \"street=\"Rnreddy nagar\"lm=\"OPP tkrcollege\" loc=\"Hyd\" vtc=\"Tirumalagiri\" po=\"Kukatpally\" dist=\"Hyderabad/>";
		ByteArrayOutputStream out = QRCode.from(xmldata).to(
				ImageType.PNG).stream();
		response.setContentType("image/png");
		response.setContentLength(out.size());
		OutputStream outStream = response.getOutputStream();
		outStream.write(out.toByteArray());
		outStream.flush();
		outStream.close();
	}

}
